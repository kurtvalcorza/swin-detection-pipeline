"""SWD review probes (torch-free; needs numpy, pillow, pycocotools). Usage: python run_probes.py <repo checkout> <out dir>"""
import io, json, os, sys, types, re, hashlib, urllib.request, random
from pathlib import Path
import numpy
from PIL import Image

repo, out = Path(sys.argv[1]), Path(sys.argv[2]); out.mkdir(parents=True, exist_ok=True)
NB = repo / 'tutorials/swin_detection_task_inference.ipynb'
nb = json.loads(NB.read_text()); cells = nb['cells']; src = lambda i: ''.join(cells[i]['source'])
sys.path.insert(0, str(repo / 'src'))
import dimer_swin_detection.metrics as M
import dimer_swin_detection.runtime as RT
assert 'torch' not in sys.modules
R = {}
code = [i for i, c in enumerate(cells) if c['cell_type'] == 'code']
alltext = '\n'.join(src(i) for i in range(len(cells)))
pos = lambda pat: next(i for i in code if pat in src(i))
R['P1_static'] = {
    'cells': len(cells), 'code_cells': len(code), 'declared': {k: nb['metadata']['dimer'].get(k) for k in ('notebook_profile', 'notebook_mode', 'notebook_spec')},
    'install_cell': pos("'-m', 'pip', 'install'"), 'restart_guard_text': 'Restart the runtime' in src(pos("'-m', 'pip', 'install'")),
    'model_staging_cell': pos('stage_missing_files(WEIGHTS_DIR'), 'python_310_check_cell': pos('sys.version_info[:2] != (3, 10)'),
    'colab_badge_in_cell0': 'colab.research.google.com' in src(0),
    'cellView_cells': sum(1 for c in cells if c.get('metadata', {}).get('cellView')), 'infrastructure_titles': sum(1 for i in code if '@title' in src(i)),
    'guided_keywords_present': {k: (k.lower() in alltext.lower()) for k in ['How to use this notebook', 'Glossary', 'Roadmap', 'Check your reasoning', 'What to notice', 'Troubleshooting', 'Conclusion', '<details>']},
    'default_flags': {'USE_BYOD': 'USE_BYOD = False' in src(13), 'USE_COCO8': 'USE_COCO8 = False' in src(13)},
}
# P2 wheel availability for the pins on the declared-unsupported Colab Python (3.12)
def wheels(pkg, ver):
    try:
        d = json.load(urllib.request.urlopen(f'https://pypi.org/pypi/{pkg}/{ver}/json', timeout=30))
        return sorted({u['filename'].split('-')[2] for u in d['urls'] if u['filename'].endswith('.whl')}), [u['filename'] for u in d['urls'] if u['filename'].endswith('.tar.gz')]
    except Exception as e:
        return f'unavailable: {e}', []
R['P2_wheels_on_pypi'] = {f'{p}=={v}': wheels(p, v) for p, v in [('torch', '2.1.2'), ('torchvision', '0.16.2'), ('mmcv', '2.1.0'), ('numpy', '1.26.4')]}
R['P2_note'] = 'torch 2.1.2 / torchvision 0.16.2 publish cp38-cp311 wheels only (PyPI); download.pytorch.org and download.openmmlab.com are unreachable from this container, so the +cpu index was not listed.'

# P3 COCO8 gated branch: fetch, digest, the notebook's own extraction and label conversion, and the metric helper
c13 = src(13)
url = re.search(r"COCO8_URL = '([^']+)'", c13).group(1); pin = re.search(r"COCO8_SHA256 = '([0-9a-f]+)'", c13).group(1)
work = out / 'coco8run'; work.mkdir(exist_ok=True)
cwd = os.getcwd(); os.chdir(work)
ns = {'numpy': numpy, 'boxes_from_yolo_labels': M.boxes_from_yolo_labels}
try:
    exec(compile(c13.replace('USE_COCO8 = False', 'USE_COCO8 = True'), 'cell13', 'exec'), ns)
finally:
    os.chdir(cwd)
gt = ns['ground_truth']
dets_perfect = [{'image_id': e['image_id'], 'class_id': b['class_id'], 'score': 0.9, 'bbox_xyxy': b['bbox_xyxy']} for e in gt for b in e['boxes']]
rng = random.Random(0)
def jit(b, s):
    x1, y1, x2, y2 = b; w, h = x2 - x1, y2 - y1
    return [x1 + s * w * rng.uniform(-1, 1), y1 + s * h * rng.uniform(-1, 1), x2 + s * w * rng.uniform(-1, 1), y2 + s * h * rng.uniform(-1, 1)]
dets_jit = [{**d, 'bbox_xyxy': jit(d['bbox_xyxy'], 0.15)} for d in dets_perfect]
import contextlib
with contextlib.redirect_stdout(io.StringIO()):
    ap_perfect = M.coco_box_ap(dets_perfect, gt); ap_jit = M.coco_box_ap(dets_jit, gt)
R['P3_coco8'] = {'url': url, 'archive_sha256_matches_pin': ns['archive_sha256'] == pin, 'archive_bytes': (work / 'sample/coco8.zip').stat().st_size,
    'images': ns['image_names'], 'ground_truth_boxes': ns['n_ground_truth_boxes'],
    'coco_box_ap_gt_as_detections': {k: ap_perfect[k] for k in ('coco_ap_50_95', 'ap50', 'ap75')},
    'coco_box_ap_boxes_jittered_15pct': {k: round(ap_jit[k], 4) for k in ('coco_ap_50_95', 'ap50', 'ap75')},
    'coco_box_ap_empty': {k: M.coco_box_ap([], gt)[k] for k in ('coco_ap_50_95', 'ap50', 'ap75')},
    'recorded_previous_carrier_on_same_images': {'coco_ap_50_95': 0.7073101933, 'ap50': 0.9570957096, 'ap75': 0.6993399340, 'gt_boxes': 17}}

# P4 validate_inputs matrix (the notebook's validation stage)
d = out / 'imgs'; d.mkdir(exist_ok=True)
def save(name, im, **kw):
    p = d / name; im.save(p, **kw); return p
cases = {
    'RGB PNG 640x480': save('rgb.png', Image.new('RGB', (640, 480), 'white')),
    'RGBA PNG': save('rgba.png', Image.new('RGBA', (64, 64), (1, 2, 3, 4))),
    'grayscale PNG': save('l.png', Image.new('L', (64, 64), 9)),
    'CMYK JPEG': save('cmyk.jpg', Image.new('CMYK', (64, 64), (0, 0, 0, 0))),
    '16-bit PNG (I;16)': save('i16.png', Image.new('I;16', (64, 64), 1000)),
    '8001x8000 (64.008 MP)': save('big.png', Image.new('L', (8001, 8000), 0)),
}
tp = d / 'text.jpg'; tp.write_text('not an image'); cases['text named .jpg'] = tp
full = (d / 'rgb.png').read_bytes(); tr = d / 'trunc.png'; tr.write_bytes(full[: len(full) // 2]); cases['truncated PNG'] = tr
cases['missing file'] = d / 'nope.png'
P4 = []
for name, p in cases.items():
    try:
        m = RT.validate_inputs(p, score_threshold=0.0, max_detections=300)
        P4.append({'case': name, 'verdict': 'accepted', 'mode': m['inputs'][0]['mode']})
    except Exception as e:
        P4.append({'case': name, 'verdict': 'refused', 'error': f'{type(e).__name__}: {e}'.replace(str(d), '<imgs>')[:200]})
for st, md in ((1.5, 300), (0.0, 0)):
    try:
        RT.validate_inputs(d / 'rgb.png', score_threshold=st, max_detections=md); P4.append({'case': f'score_threshold={st}, max_detections={md}', 'verdict': 'accepted'})
    except Exception as e:
        P4.append({'case': f'score_threshold={st}, max_detections={md}', 'verdict': 'refused', 'error': str(e)[:160]})
R['P4_validate_inputs'] = P4
(d / 'big.png').unlink()

# P5 BYOD upload branch with stand-ins
head = c13.replace('USE_BYOD = False', 'USE_BYOD = True').split("    sample_kind = 'BYOD'")[0]
def exec_upload(uploaded):
    colab = types.ModuleType('google.colab'); g = types.ModuleType('google'); g.colab = colab
    colab.files = types.SimpleNamespace(upload=lambda: uploaded); sys.modules['google'] = g; sys.modules['google.colab'] = colab
    cwd = os.getcwd(); os.chdir(work)
    try:
        n = {'numpy': numpy}; exec(compile(head, 'cell13', 'exec'), n); return {'image_paths': [str(p) for p in n['image_paths']]}
    finally:
        os.chdir(cwd)
def run(name, fn):
    try: return {'case': name, 'verdict': 'accepted', 'result': fn()}
    except Exception as e: return {'case': name, 'verdict': 'refused', 'error': f'{type(e).__name__}: {e}'[:160]}
P5 = {k: run(k, lambda u=u: exec_upload(u)) for k, u in {'cancelled dialog': {}, 'two files': {'a.png': full, 'b.png': full}}.items()}
for k in ('google', 'google.colab'): sys.modules.pop(k, None)
def outside():
    cwd = os.getcwd(); os.chdir(work)
    try: exec(compile(head, 'cell13', 'exec'), {'numpy': numpy})
    finally: os.chdir(cwd)
P5['outside Colab'] = run('outside Colab', outside)
P5['has_path_field'] = bool(re.search(r'BYOD_(IMAGE_)?PATH\s*=', c13))
R['P5_byod_upload'] = P5
(out / 'results.json').write_text(json.dumps(R, indent=2, default=str))
print(json.dumps(R, indent=1, default=str)[:6000])
